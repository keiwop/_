public class Joueur {
    int position;
    int prison;

    Joueur(){
        position = 0;
        prison = 0;
    }


}
