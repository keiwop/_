abstract class Evenement {
    abstract void agir(Joueur j);
}
