public class Jeu {

    public static void main (String args[]){
        Plateau p = new Plateau(30);
        Joueur j1 = new Joueur();
        Joueur j2 = new Joueur();
    }


}
